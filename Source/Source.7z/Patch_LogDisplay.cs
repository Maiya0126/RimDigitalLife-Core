// ============================================================================
// RimDigitalLife - Log Display Patch
// 【Version: v1.0.2 | 2025-01-29 | 修复签名增强版】
// @author Maiya0126 (麦丫)
// ============================================================================

using System;
using HarmonyLib;
using RimWorld;
using Verse;

namespace RimDigitalLife
{
    /// <summary>
    /// [v1.0.2] Harmony Patch - 修改交互日志的显示前缀
    /// 目标：为电话通话添加 [iShen 通讯 @xxx] 的绿色前缀
    ///
    /// 修复说明：
    /// - 原代码使用 Traverse.Field 访问不存在的字段
    /// - 现改用 Harmony 的 Postfix 直接修改返回值
    /// </summary>
    [HarmonyPatch(typeof(PlayLogEntry_Interaction), "ToGameStringFromPOV")]
    public static class Patch_LogDisplay
    {
        /// <summary>
        /// [v1.0.2] Postfix Patch - 在原方法执行后修改返回值
        /// </summary>
        /// <param name="__instance">被 Patch 的实例</param>
        /// <param name="pov">视角 Pawn</param>
        /// <param name="__result">原方法的返回值（可修改）</param>
        public static void Postfix(
            PlayLogEntry_Interaction __instance,
            Pawn pov,
            ref string __result)
        {
            try
            {
                // [MOD v1.1.0] 添加空值检查
                if (__instance == null || __result == null)
                {
                    return;
                }

                // [v1.1.0] 检查是否是我们的电话交互
                // 使用 Traverse 访问私有字段，因为 InteractionDef 属性在 1.6 中不存在
                var interactionDef = Traverse.Create(__instance).Field("interactionDef").GetValue<Verse.Def>();

                if (interactionDef != null && interactionDef.defName == "RimDigital_PhoneCall")
                {
                    // [v1.1.0] 获取 initiator（使用 Traverse）
                    Pawn initiator = Traverse.Create(__instance).Field("initiator").GetValue<Pawn>();

                    if (initiator != null && !string.IsNullOrEmpty(__result))
                    {
                        // 添加绿色的 iShen 通讯前缀
                        __result = $"<color=#00FF00>[iShen 通讯 @{initiator.LabelShort}]</color> " + __result;
                    }
                }
            }
            catch (Exception ex)
            {
                // [v1.1.0] 防止 Patch 导致游戏崩溃
                Log.Error($"[RimDigital: Core] Patch_LogDisplay error: {ex.Message}");
            }
        }
    }
}
