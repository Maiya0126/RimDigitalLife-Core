// ============================================================================
// RimDigitalLife - Digital Comfort Thought Worker
// 【Version: v1.0.2 | 2025-01-29 | 修复签名增强版】
// @author Maiya0126 (麦丫)
// ============================================================================

using System.Linq;
using RimWorld;
using Verse;

namespace RimDigitalLife
{
    /// <summary>
    /// [v1.0.2] 数码生活心情判定 Worker
    /// 功能：检测殖民者是否装备了任何 RimDigital 设备
    /// 如果有，给予 "数码生活" 心情加成（+3）
    /// </summary>
    public class ThoughtWorker_DigitalComfort : ThoughtWorker
    {
        /// <summary>
        /// [v1.0.2] 判定当前 Pawn 是否应该拥有此心情
        /// </summary>
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            // [MOD v1.0.2] 添加空值检查
            if (p == null || p.apparel == null)
            {
                return ThoughtState.Inactive;
            }

            // [MOD v1.0.2] 检查是否装备了任何带有 CompTerminalLink 的设备
            bool hasDigitalDevice = p.apparel.WornApparel
                .Any(ap => ap.TryGetComp<CompTerminalLink>() != null);

            if (hasDigitalDevice)
            {
                // 返回阶段 0：数码生活（+3 心情）
                return ThoughtState.ActiveAtStage(0);
            }

            return ThoughtState.Inactive;
        }
    }
}
