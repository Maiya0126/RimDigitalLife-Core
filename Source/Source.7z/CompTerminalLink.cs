// ============================================================================
// RimDigitalLife - Device Component System
// 【Version: v1.0.2 | 2025-01-29 | 修复签名增强版】
// @author Maiya0126 (麦丫)
// ============================================================================

using System;
using System.Linq;
using RimWorld;
using Verse;

namespace RimDigitalLife
{
    /// <summary>
    /// [v1.0.2] 终端设备连接组件 - 用于管理设备与殖民者的联动
    /// 功能：装备/卸下设备时自动添加/移除 Hediff
    /// </summary>
    public class CompProperties_TerminalLink : CompProperties
    {
        public CompProperties_TerminalLink()
        {
            this.compClass = typeof(CompTerminalLink);
        }
    }

    /// <summary>
    /// [v1.0.2] 终端设备组件实现类
    /// 核心逻辑：
    /// 1. 装备设备时：检查是否已有 Hediff，没有则添加
    /// 2. 卸下设备时：检查是否还有其他设备，没有则移除 Hediff
    /// </summary>
    public class CompTerminalLink : ThingComp
    {
        /// <summary>
        /// [v1.0.2] 设备被装备时触发
        /// </summary>
        public override void Notify_Equipped(Pawn pawn)
        {
            base.Notify_Equipped(pawn);

            // [MOD v1.0.2] 添加空值检查，防止崩溃
            if (pawn == null || pawn.Dead || !pawn.IsColonist)
            {
                return;
            }

            EnsureHediff(pawn);
        }

        /// <summary>
        /// [v1.0.2] 设备被卸下时触发
        /// </summary>
        public override void Notify_Unequipped(Pawn pawn)
        {
            base.Notify_Unequipped(pawn);

            // [MOD v1.0.2] 添加空值检查
            if (pawn == null || pawn.Dead)
            {
                return;
            }

            CheckAndRemoveHediff(pawn);
        }

        /// <summary>
        /// [v1.0.2] 确保殖民者拥有设备连接 Hediff
        /// </summary>
        private void EnsureHediff(Pawn pawn)
        {
            HediffDef def = HediffDef.Named("DigitalStorage_TerminalImplant");

            // [MOD v1.0.2] 添加防御性检查
            if (def == null)
            {
                Log.Error($"[RimDigital: Core] HediffDef 'DigitalStorage_TerminalImplant' not found!");
                return;
            }

            if (!pawn.health.hediffSet.HasHediff(def))
            {
                pawn.health.AddHediff(def);
            }
        }

        /// <summary>
        /// [v1.0.2] 检查并移除设备连接 Hediff（如果没有任何其他设备）
        /// </summary>
        private void CheckAndRemoveHediff(Pawn pawn)
        {
            bool hasOtherDevice = false;

            if (pawn.apparel != null)
            {
                // [MOD v1.0.2] 使用 LINQ 优化代码可读性
                hasOtherDevice = pawn.apparel.WornApparel
                    .Where(ap => ap != this.parent) // 排除当前正在卸下的设备
                    .Any(ap => ap.TryGetComp<CompTerminalLink>() != null);
            }

            // 如果没有任何其他设备，移除 Hediff
            if (!hasOtherDevice)
            {
                HediffDef def = HediffDef.Named("DigitalStorage_TerminalImplant");

                // [MOD v1.0.2] 添加空值检查
                if (def != null)
                {
                    Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(def);
                    if (hediff != null)
                    {
                        pawn.health.RemoveHediff(hediff);
                    }
                }
            }
        }
    }
}
