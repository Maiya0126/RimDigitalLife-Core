// ============================================================================
// RimDigitalLife - Phone Communication System
// 【Version: v1.0.2 | 2025-01-29 | 修复签名增强版】
// @author Maiya0126 (麦丫)
// ============================================================================

using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;
using Verse.Grammar;
using UnityEngine;

namespace RimDigitalLife
{
    /// <summary>
    /// [v1.0.2] 电话通讯交互核心类
    /// 功能：
    /// 1. 检测双方是否都有通讯设备
    /// 2. 判断忙线/拉黑状态
    /// 3. 生成成功/失败的消息和心情效果
    /// </summary>
    public class InteractionWorker_PhoneCall : InteractionWorker
    {
        /// <summary>
        /// [v1.0.2] 计算此交互的随机权重
        /// 返回 0 表示不允许此交互
        /// </summary>
        public override float RandomSelectionWeight(Pawn initiator, Pawn recipient)
        {
            // [MOD v1.0.2] 添加防御性检查
            if (initiator == null || recipient == null)
            {
                return 0f;
            }

            // 检查双方是否都有通讯设备
            if (!HasPhone(initiator) || !HasPhone(recipient))
            {
                return 0f;
            }

            // [MOD v1.0.2] 检查接收者状态
            // - 被击倒
            // - 精神崩溃
            // - 睡眠中
            if (recipient.Downed || recipient.InMentalState || !recipient.Awake())
            {
                return 0f;
            }

            // [v1.0.2] 返回交互权重（0.8 表示较高优先级）
            return 0.8f;
        }

        /// <summary>
        /// [v1.0.2] 执行交互逻辑
        /// 这是核心方法，处理成功/失败两种情况
        /// </summary>
        public override void Interacted(Pawn initiator, Pawn recipient, List<RulePackDef> extraSentencePacks,
            out string letterText, out string letterLabel, out LetterDef letterDef, out LookTargets lookTargets)
        {
            // ====================================================================
            // 失败判定逻辑
            // ====================================================================

            // [MOD v1.0.2] 获取好感度并判断失败类型
            int opinion = recipient.relations.OpinionOf(initiator);

            // 拉黑判定：好感度 < -20 且 50% 概率
            bool isBlocked = (opinion < -20 && Rand.Chance(0.5f));

            // 忙线判定：非拉黑情况下 10% 概率
            bool isBusy = (!isBlocked && Rand.Chance(0.1f));

            // 如果是失败情况（拉黑或忙线）
            if (isBlocked || isBusy)
            {
                // 初始化输出参数为空（失败时不会有信件）
                letterText = null;
                letterLabel = null;
                letterDef = null;
                lookTargets = null;

                // ====================================================================
                // 1. 心情惩罚（核心修改点）
                // ====================================================================

                int stage = isBlocked ? 1 : 0; // 1=被拉黑, 0=无人接听

                // [MOD v1.1.0] 修复 RimWorld 1.6 API 变更
                // 问题: CurStageIndex 是只读的，不能直接赋值
                // 解决: 使用 ThoughtMaker.MakeThought(thoughtDef, stage) 重载
                ThoughtDef thoughtDef = ThoughtDef.Named("RimDigital_CallRejected");

                if (thoughtDef != null)
                {
                    // [v1.1.0] 直接在 MakeThought 时指定阶段
                    Thought_Memory memory = ThoughtMaker.MakeThought(thoughtDef, stage);

                    if (memory != null)
                    {
                        initiator.needs.mood.thoughts.memories.TryGainMemory(memory, recipient);
                    }
                    else
                    {
                        // [v1.1.0] 如果失败，使用默认阶段
                        initiator.needs.mood.thoughts.memories.TryGainMemory(thoughtDef, recipient);
                    }
                }

                // ====================================================================
                // 2. 飘字反馈
                // ====================================================================

                string text = isBlocked ? "🚫 被拉黑!" : "📞 无人接听";
                MoteMaker.ThrowText(
                    initiator.DrawPos + new Vector3(0f, 0f, 0.5f),
                    initiator.Map,
                    text,
                    Color.red
                );

                // ====================================================================
                // 3. 生成失败日志（核心修改点）
                // ====================================================================

                // [MOD v1.0.2] 修复 PlayLogEntry 调用错误
                // 原代码使用了不存在的构造函数，现已删除并改用更简单的方式

                string failText = GenerateFailText(initiator, recipient, isBlocked);

                // [MOD v1.0.2] 直接输出到游戏日志（不使用 PlayLog）
                // 这样可以避免复杂的 Log Entry 创建逻辑
                Log.Message($"[RimDigital: Phone] {failText}");

                // [MOD v1.0.2] 可选：给接收者也添加一个简短的心情效果
                if (isBlocked && recipient.needs.mood != null)
                {
                    // 被拉黑时，接收者也会有轻微烦躁（表示他们拒绝了这个电话）
                    // 这里可以扩展更多逻辑
                }

                return; // [MOD v1.0.2] 提前返回，不执行正常的交互流程
            }

            // ====================================================================
            // 成功交互逻辑（调用基类方法）
            // ====================================================================

            base.Interacted(initiator, recipient, extraSentencePacks,
                out letterText, out letterLabel, out letterDef, out lookTargets);
        }

        /// <summary>
        /// [v1.0.2] 生成失败文本（使用 RulePack）
        /// </summary>
        private string GenerateFailText(Pawn initiator, Pawn recipient, bool blocked)
        {
            // [MOD v1.0.2] 添加空值检查
            if (initiator == null || recipient == null)
            {
                return "通讯失败";
            }

            string rootKeyword = blocked ? "fail_blocked" : "fail_busy";

            // 构建语法解析请求
            GrammarRequest request = default(GrammarRequest);
            request.Rules.Add(new Rule_String("INITIATOR_nameDef", initiator.LabelShort));
            request.Rules.Add(new Rule_String("RECIPIENT_nameDef", recipient.LabelShort));
            request.Includes.Add(RulePackDef.Named("RimDigital_PhoneFailRules"));

            // 解析并返回
            string result = GrammarResolver.Resolve(rootKeyword, request);

            // [MOD v1.0.2] 防止返回空字符串
            if (string.IsNullOrEmpty(result))
            {
                return blocked
                    ? $"{initiator.LabelShort} 的电话被 {recipient.LabelShort} 拒绝了。"
                    : $"{recipient.LabelShort} 没有接听 {initiator.LabelShort} 的电话。";
            }

            return result;
        }

        /// <summary>
        /// [v1.0.2] 检查 Pawn 是否拥有通讯设备
        /// </summary>
        private bool HasPhone(Pawn p)
        {
            // [MOD v1.0.2] 添加空值检查
            if (p == null || p.apparel == null)
            {
                return false;
            }

            // [MOD v1.0.2] 使用 LINQ 优化代码可读性
            return p.apparel.WornApparel
                .Any(ap => ap.def.apparel.tags.Contains("RimPhone_Communication"));
        }
    }
}
