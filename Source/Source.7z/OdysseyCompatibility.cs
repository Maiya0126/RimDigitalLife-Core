// ============================================================================
// RimDigitalLife - Odyssey DLC Integration
// 【Version: v1.1.0 | 2025-12-XX | 1.6 + Odyssey兼容版】
// @author Maiya0126 (麦丫)
// ============================================================================

using System;
using RimWorld;
using Verse;
using HarmonyLib;

namespace RimDigitalLife
{
    /// <summary>
    /// [v1.1.0] 奥德赛 DLC 联动模块
    ///
    /// 功能说明：
    /// 1. 太空中的通讯加成（船舰上使用设备有额外效果）
    /// 2. 星际旅行时的设备限制（某些设备无法在超光速中使用）
    /// 3. 船舰系统集成（可以作为船舰建筑的一部分）
    ///
    /// 签名: 6Zt4562w5p2lTWFpeWEwMTI2
    /// </summary>
    public static class OdysseyCompatibility
    {
        /// <summary>
        /// [v1.1.0] 检查是否加载了奥德赛 DLC
        /// </summary>
        public static bool HasOdysseyDLC
        {
            get
            {
                // [v1.1.0] 修复 RimWorld 1.6 API 变更
                // ActivePacksInLoadOrder 不存在，改用 ModLister
                return ModLister.GetActiveModWithIdentifier("Ludeon.RimWorld.Odyssey") != null;
            }
        }

        /// <summary>
        /// [v1.1.0] 检查 Pawn 是否在船舰上
        /// </summary>
        public static bool IsOnShip(Pawn pawn)
        {
            if (pawn == null || pawn.Map == null)
            {
                return false;
            }

            // [v1.1.0] RimWorld 1.6 的船舰检测 API 变更
            // HasShipMap 不存在，暂时返回 false
            // 实际需要查找正确的 1.6 API
            return false; // 占位符
        }

        /// <summary>
        /// [v1.1.0] 检查 Pawn 是否正在进行星际旅行
        /// </summary>
        public static bool IsInInterstellarTravel(Pawn pawn)
        {
            if (pawn == null)
            {
                return false;
            }

            // [v1.1.0] 检查是否处于超光速旅行状态
            // 这里需要根据 1.6 的实际 API 调整
            return false; // 占位符，实际需要 1.6 的 API
        }

        /// <summary>
        /// [v1.1.0] 获取太空通讯加成
        /// 在船舰上使用通讯设备时有额外效果
        /// </summary>
        public static float GetSpaceCommunicationBonus(Pawn pawn)
        {
            if (!HasOdysseyDLC || !IsOnShip(pawn))
            {
                return 0f;
            }

            // [v1.1.0] 船舰上的通讯设备有 20% 加成
            // 因为太空中需要依赖设备与地球联系
            return 0.2f;
        }

        /// <summary>
        /// [v1.1.0] 检查设备是否可以在当前环境使用
        /// 某些设备可能在星际旅行时无法使用
        /// </summary>
        public static bool CanUseDevice(Pawn pawn, Thing device)
        {
            if (pawn == null || device == null)
            {
                return false;
            }

            // [v1.1.0] 示例：某些基础设备（如 Nokirim 3310）
            // 即使在星际旅行中也能使用
            if (device.def.defName == "Apparel_Rimkia")
            {
                return true;
            }

            // [v1.1.0] 高级设备（如 iShen Phone）
            // 在超光速旅行时可能受到干扰
            if (IsInInterstellarTravel(pawn) && device.def.defName == "Apparel_Rimdle")
            {
                return false;
            }

            return true;
        }
    }

    /// <summary>
    /// [v1.1.0] Odyssey Harmony Patch
    /// 为船舰上的殖民者添加特殊的通讯心情
    /// </summary>
    [HarmonyPatch(typeof(InteractionWorker_PhoneCall), "RandomSelectionWeight")]
    public static class Patch_OdysseyCommunication
    {
        /// <summary>
        /// [v1.1.0] Postfix - 在太空中通讯的权重更高
        /// </summary>
        public static void Postfix(Pawn initiator, Pawn recipient, ref float __result)
        {
            // [v1.1.0] 检查是否在船舰上
            if (OdysseyCompatibility.HasOdysseyDLC
                && OdysseyCompatibility.IsOnShip(initiator))
            {
                // [v1.1.0] 船舰上通讯权重增加 50%
                // 因为太空中与外界联系更加珍贵
                __result *= 1.5f;
            }
        }
    }
}
